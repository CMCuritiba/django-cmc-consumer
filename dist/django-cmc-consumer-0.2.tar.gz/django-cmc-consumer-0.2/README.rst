============
CMC Consumer
============

Module that consumes CMC Services.


Quick start
-----------

1. Add "cmcconsumer" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'consumer',
    ]